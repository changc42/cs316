import java.util.*;
import java.io.*;
import java.util.Scanner;

class Assignment1{
  public static void main(String[] args){
    // try{
    //   File input = new File(args[0]);
    //   Scanner reader = new Scanner(input);
    //   while(reader.hasNextLine()){
    //     String line = reader.nextLine();
    //     System.out.println(line);
    //   }
    //   reader.close();
    // }catch(FileNotFoundException e){
    //   System.out.println("error occurred when trying to read file");
    //   System.out.println(e);
    // }
    
    LexicalAnalyzer myLA = new LexicalAnalyzer(args[0]);
    Token token;
    do{
      token = myLA.getToken();
      System.out.println(String.format("Next token is %d, Next lexeme is %s", token.getTokenCode(), token.getLexemeString() ));
    } while(token.getTokenCode()!=-1);
  }
}